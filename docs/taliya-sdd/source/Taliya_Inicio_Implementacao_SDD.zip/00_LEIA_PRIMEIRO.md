# Iniciar a implementação da Taliya

Este arquivo organiza a passagem para outra conversa ou ambiente de código. Não é uma nova auditoria geral nem uma nova arquitetura.

## Uso

1. Disponibilize este ZIP e os repositórios ou ZIPs atuais de landing/Internal e app/billing. O plano não inclui o código-fonte completo da aplicação.
2. Cole o conteúdo de `PROMPT_INICIO_TALIYA_SDD.md` na conversa do agente de implementação.
3. O agente deve ler a base `Taliya_Plano_Integral_SDD_v3/`, reconciliar o estado atual e iniciar a spec de fundação.
4. Continue por dependências e mantenha evidências e um checkpoint persistente no repositório.

O prompt da raiz é a instrução atual de início. Ele substitui somente o prompt anterior de continuidade. Os 95 arquivos do plano v3 permanecem byte a byte como recebidos; este invólucro não muda o escopo do produto.

## Prontidão

A base está pronta para começar a implementação pela fundação. Não é código integrado, implantação pronta ou homologação. Contratos reais, acesso autorizado às contas, materiais aprovados e gates operacionais serão resolvidos nas etapas correspondentes.

Não é necessário aguardar todos os vídeos ou credenciais para fazer a inspeção e o trabalho local independente. A ausência de uma dependência não permite inventá-la nem encerrar falsamente a integração.

## Conteúdo desta entrega

- `PROMPT_INICIO_TALIYA_SDD.md`: prompt completo para copiar.
- `REVISAO_DE_PRONTIDAO.md`: limites e orientações de entrada.
- `VERIFICACAO_DO_PACOTE.json`: resultados da conferência estrutural.
- `Taliya_Plano_Integral_SDD_v3/`: plano original completo, incluindo PDF e specs.

As chaves devem permanecer no mecanismo de segredos do ambiente. Não anexar arquivos .env com segredos reais ao chat.
