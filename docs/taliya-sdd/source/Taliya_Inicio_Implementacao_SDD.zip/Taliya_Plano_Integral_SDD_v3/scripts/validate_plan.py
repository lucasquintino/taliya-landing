#!/usr/bin/env python3
"""Validate this planning package only. Never calls external APIs."""
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding="utf-8"))
def main():
    checks=[]
    def check(name, condition):
        checks.append({"name":name,"passed":bool(condition)})
        if not condition: raise ValueError(name)
    for p in ROOT.rglob("*.json"):
        json.loads(p.read_text(encoding="utf-8"))
    check("all_json_parse",True)
    program=load("planning/program.json")["stages"]
    ids={s["id"] for s in program}
    check("13_unique_specs",len(ids)==len(program)==13)
    check("planned_weights_100_not_current_progress",sum(s["weight"] for s in program)==100)
    reqs=load("planning/requirements.json"); cases=load("evals/acceptance-cases.json"); tasks=load("planning/tasks.json")
    rid={r["id"] for r in reqs};cid={c["id"] for c in cases}
    check("65_unique_requirements",len(rid)==len(reqs)==65)
    check("65_unique_acceptance_cases",len(cid)==len(cases)==65)
    check("78_unique_work_items",len({t["id"] for t in tasks})==len(tasks)==78)
    check("all_requirements_have_tests",all(r["test_ids"] and set(r["test_ids"])<=cid for r in reqs))
    check("no_orphan_test",all(set(c["requirement_ids"])<=rid for c in cases))
    check("no_orphan_task",all(set(t["requirement_ids"])<=rid for t in tasks))
    check("all_requirements_have_work",rid <= set().union(*(set(t["requirement_ids"]) for t in tasks)))
    visited=set();visiting=set()
    byid={s["id"]:s for s in program}
    def visit(i):
        if i in visiting: raise ValueError("cyclic dependency")
        if i in visited:return
        visiting.add(i)
        for d in byid[i]["deps"]:
            if d not in ids:raise ValueError("unknown dependency")
            visit(d)
        visiting.remove(i);visited.add(i)
    for i in ids:visit(i)
    check("dependency_graph_acyclic",True)
    for s in program:
        for fn in ("spec.md","plan.md","tasks.md","verification.md"):
            check("artifact_"+s["id"]+"_"+fn,(ROOT/"specs"/s["directory"]/fn).is_file())
    check("acceptance_not_misrepresented_as_run",all(c["execution_status"]=="not_run" for c in cases))
    check("implementation_not_misrepresented_as_done",all(t["status"]=="not_started" for t in tasks))
    conf=load("agent/config.intent.json")
    check("luna_max",conf["model"]=="gpt-6-luna" and conf["reasoning_effort"]=="max")
    check("five_functions",len(load("contracts/tools.json"))==5)
    check("no_fake_media",load("contracts/materials.catalog.json")["assets"]==[])
    check("one_material_per_reply",load("contracts/reply.schema.json")["properties"]["asset_ids"]["maxItems"]==1)
    catalog=load("contracts/events.catalog.v3.json")
    envelope=load("contracts/event.envelope.schema.json")
    check("43_unique_events",len({e["name"] for e in catalog})==len(catalog)==43)
    check("event_enum_matches_catalog",set(envelope["properties"]["event_name"]["enum"])=={e["name"] for e in catalog})
    check("event_version_type_consistent",envelope["properties"]["event_version"]["type"]=="integer" and all(isinstance(e["version"],int) for e in catalog))
    check("event_producers_match",set(envelope["properties"]["producer"]["enum"])=={e["producer"] for e in catalog})
    for stage in program:
        sid=stage["id"]
        text=(ROOT/"specs"/stage["directory"]/"tasks.md").read_text(encoding="utf-8")
        check("tasks_traceability_"+sid,all(
            all(r in next(line for line in text.splitlines() if task["id"] in line) for r in task["requirement_ids"])
            for task in tasks if task["spec"]==sid))
    check("validation_report_present",(ROOT/"evidence"/"VALIDACAO_DESTA_ENTREGA.md").is_file())
    report={"scope":"planning_integrity_only","checks_passed":len(checks),"checks":checks,"acceptance_cases_executed":0,"live_model_calls":0,"production_changes":0}
    (ROOT/"evidence"/"plan-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"checks_passed":len(checks),"scope":report["scope"]},ensure_ascii=False))
if __name__=="__main__":
    try:main()
    except (ValueError,KeyError,OSError) as e:
        print(str(e),file=sys.stderr);sys.exit(1)
