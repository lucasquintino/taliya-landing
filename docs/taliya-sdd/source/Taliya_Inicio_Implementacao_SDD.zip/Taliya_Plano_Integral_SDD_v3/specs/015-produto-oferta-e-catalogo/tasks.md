# 015 — Fonte única de produto, oferta e materiais

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** Produto + frontend/backend.
**Dependências:** 013.

## Tarefas
- [ ] **T015-01** — Consolidar capacidades reais por integração/documento aprovado e remover catálogo comercial de Pilates do caminho v2. Requisitos: R015-01.
- [ ] **T015-02** — Implementar leitor de oferta publicado, com versão e data; cache com invalidação compatível com o billing. Requisitos: R015-02, R015-05.
- [ ] **T015-03** — Definir schema do catálogo compartilhado e pasta/serviço já existente para armazenamento. Requisitos: R015-03.
- [ ] **T015-04** — Importar somente vídeos/demos/UGCs entregues e autorizados; preparar transcrição/resumo/caption. Requisitos: R015-03.
- [ ] **T015-05** — Implementar validação de publicação, URL, revisão e expiração de material; não criar CMS novo. Requisitos: R015-03, R015-04, R015-05.
- [ ] **T015-06** — Testar mudanças de oferta/material durante conversa ativa e publicar guia de edição. Requisitos: R015-01, R015-02, R015-03, R015-04, R015-05.

Não marcar uma tarefa porque o arquivo existe. Acrescentar caminho do diff, comando e resultado verificável ao concluí-la. Se o código atual já atende, comprovar por teste e registrar reuso em vez de reimplementar.
