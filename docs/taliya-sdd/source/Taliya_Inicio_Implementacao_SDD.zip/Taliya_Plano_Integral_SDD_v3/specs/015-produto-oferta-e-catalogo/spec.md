# 015 — Fonte única de produto, oferta e materiais

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** Produto + frontend/backend.
**Dependências:** 013.

## Resultado
Fazer landing, agente e materiais descreverem o mesmo produto pronto com a mesma oferta vigente.

## Requisitos verificáveis
### R015-01
Criar catálogo versionado de capacidades publicadas, limites e FAQ.

**Aceite:** Somente recursos confirmados entram; equipes/booking e outros recursos antigos não são presumidos por aparecer em documento histórico.
**Verificação:** C015-01.

### R015-02
Consumir a oferta do billing pronto por contrato central, sem preço duplicado no prompt.

**Aceite:** Mensal/anual, cobrança inicial e garantia de 14 dias são coerentes; nenhum teste sem cartão é vendido.
**Verificação:** C015-02.

### R015-03
Catalogar mídia com aprovação, origem e classificação de prova social.

**Aceite:** Cada material publicado possui ID, tipo, URL autorizada, versão, resumo/transcrição, direitos e status; UGC encenado não vira depoimento.
**Verificação:** C015-03.

### R015-04
Definir comportamento quando informações ou materiais faltam.

**Aceite:** A informação ausente é explicitada; o agente não inventa preço, link, prazo ou mídia e o CTA depende de destino válido.
**Verificação:** C015-04.

### R015-05
Versionar e propagar atualizações.

**Aceite:** Oferta nova é consultada no momento relevante; material retirado não é emitido em sessão antiga; compatibilidade e freshness ficam registradas.
**Verificação:** C015-05.

## Limites
Não reconstruir app/billing, não implantar sem autorização, não criar outro CRM/BI, não ampliar poderes do agente. Preservar a aparência aprovada. Escopo não resolvido é registrado como bloqueio da tarefa dependente; não inventar endpoints, credenciais, materiais ou resultado de testes.

## Definição de conclusão
Todos os requisitos desta spec possuem evidência de implementação e teste; artefatos estão coerentes; nenhuma restrição de segurança/comercial foi afrouxada silenciosamente. Checklist de requisitos aprovada não é sinônimo de implementação concluída.
