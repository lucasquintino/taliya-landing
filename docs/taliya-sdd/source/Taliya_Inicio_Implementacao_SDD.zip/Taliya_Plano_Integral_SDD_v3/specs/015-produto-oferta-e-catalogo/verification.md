# 015 — Verificação e evidências

**Estado:** casos especificados; nenhum caso de aceitação foi executado nesta auditoria.

## C015-01 · R015-01
**Cenário:** Perguntar sobre capacidades atuais, recursos indisponíveis e funcionamento antigo de Pilates; comparar resposta e FAQ com a fonte aprovada.

**Resultado exigido:** Somente recursos confirmados entram; equipes/booking e outros recursos antigos não são presumidos por aparecer em documento histórico.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C015-02 · R015-02
**Cenário:** Comparar página, resposta do agente e oferta de contratação em mensal/anual; perguntar sobre teste sem cartão e garantia vigente.

**Resultado exigido:** Mensal/anual, cobrança inicial e garantia de 14 dias são coerentes; nenhum teste sem cartão é vendido.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C015-03 · R015-03
**Cenário:** Importar creator demonstrando produto e depoimento verificado; tentar publicar um arquivo sem aprovação ou direitos registrados.

**Resultado exigido:** Cada material publicado possui ID, tipo, URL autorizada, versão, resumo/transcrição, direitos e status; UGC encenado não vira depoimento.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C015-04 · R015-04
**Cenário:** Desativar a fonte de produto e retirar o vídeo solicitado; verificar que o agente informa o limite sem oferecer link, preço ou acesso inventado.

**Resultado exigido:** A informação ausente é explicitada; o agente não inventa preço, link, prazo ou mídia e o CTA depende de destino válido.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C015-05 · R015-05
**Cenário:** Atualizar oferta, FAQ e situação de material durante uma sessão existente; conferir invalidação e versão usada em cada nova resposta.

**Resultado exigido:** Oferta nova é consultada no momento relevante; material retirado não é emitido em sessão antiga; compatibilidade e freshness ficam registradas.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## Regressões adicionais da frente
- Preço na página e resposta comercial vêm da mesma versão publicada.
- Pergunta sobre teste sem cartão recebe explicação da garantia atual.
- Vídeo removido/privado não gera card quebrado nem URL inventada.
- Creator contratado não é apresentado como cliente comprovado.
- Fonte indisponível produz fallback honesto sem retornar planos de Pilates.

Os IDs de caso são estáveis; o detalhamento técnico cresce com os contratos reais. Mock não comprova chamada externa, análise estática não comprova produção.
