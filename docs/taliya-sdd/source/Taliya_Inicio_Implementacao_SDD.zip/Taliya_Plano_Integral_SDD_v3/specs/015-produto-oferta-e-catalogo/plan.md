# 015 — Fonte única de produto, oferta e materiais

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** Produto + frontend/backend.
**Dependências:** 013.

## Abordagem técnica
Fazer landing, agente e materiais descreverem o mesmo produto pronto com a mesma oferta vigente.

A abordagem de domínio e as interfaces propostas estão em `../../03_ARQUITETURA_E_CONTRATOS.md`. A implementação deve referenciar as interfaces reais descobertas na 013; os caminhos abaixo pertencem ao ZIP inspecionado e são candidatos de integração, não prova da árvore atual.

## Pontos de integração observados
- `data/landing/niches/pilates.ts`
- `lib/landing/ai-attendant/commercial-knowledge.ts`
- `services/taliya-agent-runtime/app/shared/product_knowledge/source.py`
- `docs/landing-migration/shared-contracts.md`

## Ordem de execução
1. Consolidar capacidades reais por integração/documento aprovado e remover catálogo comercial de Pilates do caminho v2.
2. Implementar leitor de oferta publicado, com versão e data; cache com invalidação compatível com o billing.
3. Definir schema do catálogo compartilhado e pasta/serviço já existente para armazenamento.
4. Importar somente vídeos/demos/UGCs entregues e autorizados; preparar transcrição/resumo/caption.
5. Implementar validação de publicação, URL, revisão e expiração de material; não criar CMS novo.
6. Testar mudanças de oferta/material durante conversa ativa e publicar guia de edição.

## Dados, permissões e observabilidade
Cada mudança de estado material deve ter ator, autorização, recibo persistido e evento de domínio. Fronteiras entre bancos/serviços usam outbox e reconciliação, não uma transação distribuída presumida. Métricas públicas de browser não comprovam dinheiro ou acesso. Não registrar segredos ou dados de terceiros em prompts/analytics.

## Testes e rollback
Executar os casos `C015-01` a `C015-05` e a regressão dos contratos afetados. Usar feature flag da capacidade e migrações compatíveis para rollback; nenhuma volta ao roteiro Pilates. Registrar em `verification.md`.

## Esforço de referência
2–3 dias de engenharia focada, estimativa de planejamento, não prazo garantido. Não inclui espera por autorização, fornecimento de mídia ou acesso externo. Reestimar ao fechar 013.
