# 013 — Fundação, governança e contratos do produto pronto

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** Liderança técnica + responsável pelo produto.
**Dependências:** nenhuma.

## Tarefas
- [ ] **T013-01** — Gerar inventário e matriz de autoridade a partir do commit atual; resolver rotas Internal locais/remotas. Requisitos: R013-01.
- [ ] **T013-02** — Registrar contratos existentes de conta/negócio/assinatura/status e retorno à contratação; executar consultas de homologação autorizadas. Requisitos: R013-01, R013-03.
- [ ] **T013-03** — Aplicar o adendo scoped de AGENTS/constituição; arquivar regras antigas sem excluí-las. Requisitos: R013-02.
- [ ] **T013-04** — Verificar Spec Kit instalado, scripts ps/sh/py e disponibilidade de converge; fixar versão e registrar comandos corretos. Requisitos: R013-04.
- [ ] **T013-05** — Salvar baselines de desktop/mobile e mapa de dependências materiais/contas/políticas; não ativar serviços pagos. Requisitos: R013-05.
- [ ] **T013-06** — Revisar checklist de requisitos, plan/tasks e registrar evidências sanitizadas antes de liberar a 014/015. Requisitos: R013-01, R013-02, R013-03, R013-04, R013-05.

Não marcar uma tarefa porque o arquivo existe. Acrescentar caminho do diff, comando e resultado verificável ao concluí-la. Se o código atual já atende, comprovar por teste e registrar reuso em vez de reimplementar.
