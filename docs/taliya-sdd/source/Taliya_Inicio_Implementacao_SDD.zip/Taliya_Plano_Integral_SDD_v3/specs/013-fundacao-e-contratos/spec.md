# 013 — Fundação, governança e contratos do produto pronto

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** Liderança técnica + responsável pelo produto.
**Dependências:** nenhuma.

## Resultado
Registrar o estado real, retirar conflitos de autoridade e fixar as interfaces que já existem, sem reconstruir app ou assinatura.

## Requisitos verificáveis
### R013-01
Registrar commit, repositórios e donos dos contratos atuais de app, billing, landing, Internal e agente.

**Aceite:** O mapa contém endpoints reais, autenticação, IDs, estados, payloads sanitizados e responsáveis; nenhuma rota inventada é aprovada.
**Verificação:** C013-01.

### R013-02
Substituir regras de copy-only apenas no escopo desta nova entrega, preservando identidade visual e históricos.

**Aceite:** AGENTS/constituição/pointer não direcionam novas tarefas ao projeto Pilates e não autorizam redesign ou deploy automático.
**Verificação:** C013-02.

### R013-03
Preservar o app e a assinatura prontos, herdando a oferta publicada.

**Aceite:** O mapa marca-os como fornecidos pelo usuário e somente integração/regressão aparece como trabalho, salvo defeito comprovado.
**Verificação:** C013-03.

### R013-04
Fixar uma versão operacional do Spec Kit e um método de scripts compatível com a máquina.

**Aceite:** A integração Codex e as invocações disponíveis são verificadas; nenhum --force apaga customizações e o ponteiro aponta à spec ativa.
**Verificação:** C013-04.

### R013-05
Registrar fontes, baselines e disponibilidade dos serviços.

**Aceite:** Há inventário de materiais disponíveis, ambientes, credenciais necessárias sem valores, baseline visual e gates por dependência.
**Verificação:** C013-05.

## Limites
Não reconstruir app/billing, não implantar sem autorização, não criar outro CRM/BI, não ampliar poderes do agente. Preservar a aparência aprovada. Escopo não resolvido é registrado como bloqueio da tarefa dependente; não inventar endpoints, credenciais, materiais ou resultado de testes.

## Definição de conclusão
Todos os requisitos desta spec possuem evidência de implementação e teste; artefatos estão coerentes; nenhuma restrição de segurança/comercial foi afrouxada silenciosamente. Checklist de requisitos aprovada não é sinônimo de implementação concluída.
