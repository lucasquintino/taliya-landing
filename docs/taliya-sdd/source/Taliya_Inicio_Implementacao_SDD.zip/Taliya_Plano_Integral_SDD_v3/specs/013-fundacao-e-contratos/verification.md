# 013 — Verificação e evidências

**Estado:** casos especificados; nenhum caso de aceitação foi executado nesta auditoria.

## C013-01 · R013-01
**Cenário:** Comparar o commit atual com o ZIP e inspecionar os contratos de app, billing, landing e Internal, incluindo rotas locais e remotas.

**Resultado exigido:** O mapa contém endpoints reais, autenticação, IDs, estados, payloads sanitizados e responsáveis; nenhuma rota inventada é aprovada.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C013-02 · R013-02
**Cenário:** Executar o agente de código na nova spec com as regras anteriores de copy-only ainda presentes no histórico; verificar o adendo de escopo efetivamente aplicado.

**Resultado exigido:** AGENTS/constituição/pointer não direcionam novas tarefas ao projeto Pilates e não autorizam redesign ou deploy automático.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C013-03 · R013-03
**Cenário:** Resolver cadastro, oferta e contratação nos serviços já prontos e verificar que nenhuma segunda base de contas ou cobrança foi proposta.

**Resultado exigido:** O mapa marca-os como fornecidos pelo usuário e somente integração/regressão aparece como trabalho, salvo defeito comprovado.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C013-04 · R013-04
**Cenário:** Executar verificação da integração Spec Kit na máquina-alvo e localizar a spec ativa pelos comandos realmente instalados.

**Resultado exigido:** A integração Codex e as invocações disponíveis são verificadas; nenhum --force apaga customizações e o ponteiro aponta à spec ativa.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## C013-05 · R013-05
**Cenário:** Revisar baseline visual, inventário de mídia, ambientes e dependências; simular uma dependência ausente sem bloquear recortes independentes.

**Resultado exigido:** Há inventário de materiais disponíveis, ambientes, credenciais necessárias sem valores, baseline visual e gates por dependência.

**Evidência a produzir:** commit/ambiente, procedimento ou comando, dados sanitizados, resultado observado e responsável.

## Regressões adicionais da frente
- O repositório atual diverge do ZIP: diferenças são documentadas sem sobrescrever progresso.
- App e billing existentes são encontrados sem segunda base de contas.
- As instruções antigas de proibir backend não bloqueiam o escopo novo nem autorizam redesign.
- Codex resolve a spec correta sem retornar a 001-fundacao-migracao.
- Dependência indisponível bloqueia somente a tarefa dependente e continua o trabalho independente.

Os IDs de caso são estáveis; o detalhamento técnico cresce com os contratos reais. Mock não comprova chamada externa, análise estática não comprova produção.
