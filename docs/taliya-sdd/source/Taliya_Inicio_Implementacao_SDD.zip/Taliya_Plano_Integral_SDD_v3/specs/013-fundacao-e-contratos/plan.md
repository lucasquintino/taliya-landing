# 013 — Fundação, governança e contratos do produto pronto

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** Liderança técnica + responsável pelo produto.
**Dependências:** nenhuma.

## Abordagem técnica
Registrar o estado real, retirar conflitos de autoridade e fixar as interfaces que já existem, sem reconstruir app ou assinatura.

A abordagem de domínio e as interfaces propostas estão em `../../03_ARQUITETURA_E_CONTRATOS.md`. A implementação deve referenciar as interfaces reais descobertas na 013; os caminhos abaixo pertencem ao ZIP inspecionado e são candidatos de integração, não prova da árvore atual.

## Pontos de integração observados
- `AGENTS.md`
- `.specify/memory/constitution.md`
- `.specify/feature.json`
- `.specify/init-options.json`
- `next.config.ts`
- `docs/landing-migration/decisions.md`

## Ordem de execução
1. Gerar inventário e matriz de autoridade a partir do commit atual; resolver rotas Internal locais/remotas.
2. Registrar contratos existentes de conta/negócio/assinatura/status e retorno à contratação; executar consultas de homologação autorizadas.
3. Aplicar o adendo scoped de AGENTS/constituição; arquivar regras antigas sem excluí-las.
4. Verificar Spec Kit instalado, scripts ps/sh/py e disponibilidade de converge; fixar versão e registrar comandos corretos.
5. Salvar baselines de desktop/mobile e mapa de dependências materiais/contas/políticas; não ativar serviços pagos.
6. Revisar checklist de requisitos, plan/tasks e registrar evidências sanitizadas antes de liberar a 014/015.

## Dados, permissões e observabilidade
Cada mudança de estado material deve ter ator, autorização, recibo persistido e evento de domínio. Fronteiras entre bancos/serviços usam outbox e reconciliação, não uma transação distribuída presumida. Métricas públicas de browser não comprovam dinheiro ou acesso. Não registrar segredos ou dados de terceiros em prompts/analytics.

## Testes e rollback
Executar os casos `C013-01` a `C013-05` e a regressão dos contratos afetados. Usar feature flag da capacidade e migrações compatíveis para rollback; nenhuma volta ao roteiro Pilates. Registrar em `verification.md`.

## Esforço de referência
1–2 dias de engenharia focada, estimativa de planejamento, não prazo garantido. Não inclui espera por autorização, fornecimento de mídia ou acesso externo. Reestimar ao fechar 013.
