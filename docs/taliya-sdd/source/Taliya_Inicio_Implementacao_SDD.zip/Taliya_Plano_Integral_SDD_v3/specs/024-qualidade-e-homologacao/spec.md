# 024 — QA integrada, segurança, performance e evals

**Status:** proposta de execução; implementação não iniciada nesta auditoria.
**Responsável:** QA + backend/frontend + produto.
**Dependências:** 018, 019, 020, 021, 022, 023.

## Resultado
Provar a jornada completa com dados controlados e falhas deliberadas antes da liberação.

## Requisitos verificáveis
### R024-01
Executar suíte automatizada de unidade/contrato/integração/E2E.

**Aceite:** Build, lint, tipos e testes do código tocado passam no CI; testes antigos têm destino explícito: preservar/adaptar/arquivar.
**Verificação:** C024-01.

### R024-02
Avaliar Luna Max com conversas reais de homologação e critérios reproduzíveis.

**Aceite:** 65 casos do plano e cenários reutilizáveis anteriores têm resultado; casos críticos repetidos não podem falhar; amostra de linguagem recebe revisão humana.
**Verificação:** C024-02.

### R024-03
Testar todas as combinações da assinatura existente como regressão de integração.

**Aceite:** Mensal/anual × cartão/Pix Automático + retorno, erro, cancelamento e reembolso refletem o serviço pronto; não reconstruir fluxo.
**Verificação:** C024-03.

### R024-04
Validar falhas, acessibilidade, desempenho e segurança.

**Aceite:** IDOR, injeção, URL arbitrária, repetição, takeover, desconexão, fila, cookies e restauração possuem evidências.
**Verificação:** C024-04.

### R024-05
Concluir critérios sem rebaixar exigência silenciosamente.

**Aceite:** Nenhum P0/P1 de lançamento aberto; metas não atingidas geram correção ou exceção explícita, não marcação verde por criar documentação.
**Verificação:** C024-05.

## Limites
Não reconstruir app/billing, não implantar sem autorização, não criar outro CRM/BI, não ampliar poderes do agente. Preservar a aparência aprovada. Escopo não resolvido é registrado como bloqueio da tarefa dependente; não inventar endpoints, credenciais, materiais ou resultado de testes.

## Definição de conclusão
Todos os requisitos desta spec possuem evidência de implementação e teste; artefatos estão coerentes; nenhuma restrição de segurança/comercial foi afrouxada silenciosamente. Checklist de requisitos aprovada não é sinônimo de implementação concluída.
