# Implementar Taliya — continuidade com SDD + Spec Kit

Você dará continuidade à implementação da Taliya no repositório atual. Não é um produto novo nem uma solicitação de outra auditoria geral. Quero executar o plano anexo, começando pela fundação e avançando por entregas verificáveis.

## 1. Fonte e decisões fechadas

Use `Taliya_Plano_Integral_SDD_v3/`, incluído no pacote de início. Este prompt complementa os cuidados de execução e substitui apenas o prompt anterior de continuidade; não substitui o escopo e os requisitos do plano.

Não dependa do histórico de outra conversa. As decisões são:

- O app e a assinatura já estão prontos conforme minha informação. Integre os serviços existentes; verifique seus contratos sem reconstruir app, autenticação ou billing.
- Use Agents API com `gpt-6-luna` e esforço `max`, um agente, ambiente `none`, sem subagentes, shell, SQL genérico ou navegação livre. Não troque modelo ou esforço silenciosamente.
- Preserve a landing, o design system e a arquitetura aprovados. Faça somente as adaptações necessárias às jornadas e integrações.
- A pessoa pode contratar diretamente, sem conversar com a IA. O agente responde dúvidas, seleciona materiais e solicita operações autorizadas.
- Leads, pessoas, negócios, assinaturas e conversas devem ser vinculados sem cadastros paralelos. O backend confirma os acontecimentos; o modelo não decide pagamento ou acesso.
- PostHog concentra métricas, funis, segmentos e automações previstas. Internal fica restrito à operação: atendimento e ficha de contato/cliente. Não construir outro CRM, BI, CMS ou caixa de atendimento.
- A assinatura usa Asaas, mensal/anual, cartão recorrente/Pix Automático, cobrança na contratação e garantia de reembolso em 14 dias. Preços, URLs e condições vigentes vêm do serviço publicado. Não usar a antiga oferta de teste sem cobrança.
- Vídeos, demonstrações e UGCs usarão um catálogo compartilhado. Só publicar materiais reais aprovados; não inventar mídia ou prova social.

## 2. Leitura e preservação

Leia primeiro os `AGENTS.md` aplicáveis e as instruções do repositório. Depois leia, dentro do pacote:
`00_COMECE_AQUI.md`, `01_AUDITORIA.md`, `02_PLANO_MESTRE_0_A_100.md`, `03_ARQUITETURA_E_CONTRATOS.md`, `04_SDD_SPECKIT.md`, `05_MATRIZ_DE_COBERTURA.md` e `10_DEPENDENCIAS_ESTIMATIVA_E_DECISOES.md`.

Para cada etapa, leia também sua spec, plan, tasks, verification, contratos, testes e evidências pertinentes.

O código atual comprova o estado implementado; minhas decisões e as specs definem o estado desejado. Não confunda código legado com requisito aprovado. Registre divergências antes de agir.

O pacote não contém o código-fonte completo da aplicação. Procure os repositórios/arquivos disponíveis no ambiente e na conversa. Se realmente faltar uma fonte necessária, solicite apenas ela. Não simule acesso nem invente endpoints.

Não extraia o pacote por cima do projeto inteiro. Incorpore os artefatos por diff revisável, preservando alterações locais, specs existentes e históricos.

## 3. Comece pela spec de fundação

Inicie `013-fundacao-e-contratos`. Confira antes se 013–025 ainda estão livres. Se houver colisão, faça um mapeamento consistente e atualize as referências, sem sobrescrever specs.

Primeiro:
1. Identifique repositórios, branch, commit ou snapshot e alterações locais de landing, Internal, agente e app/billing.
2. Verifique a versão e integração reais do Spec Kit, scripts disponíveis e spec ativa. Não force uma reinicialização nem finja executar comandos indisponíveis.
3. Reconcilie as restrições antigas de copy-only/Pilates com este escopo, mediante adendo limitado e rastreável. Preserve as proteções visuais e operacionais.
4. Mapeie os contratos reais de identidade, conta/negócio, oferta, checkout, assinatura, acesso, eventos e atendimento humano. Registre autenticação, IDs, payloads sanitizados, estados, erros e responsáveis.
5. Confirme o que já está implementado e reutilize. Verifique qual implantação atende o Internal local/remoto. Os achados do ZIP precisam ser confirmados no código atual antes de virar correções.
6. Registre ambientes, baselines, materiais disponíveis, permissões e dependências. Não exponha segredos.

Feche a parte executável dessa spec com evidências. Não termine apenas repetindo o plano que já está entregue.

## 4. Execute com SDD de verdade

Para cada spec: requisitos → esclarecimentos materiais → plano técnico → checklist → tarefas → análise de consistência → implementação → testes → convergência/revisão → evidências.

Use as invocações realmente disponíveis na instalação. Os artefatos são uma base, não prova de que o CLI foi executado. Antes de codificar o recorte, detalhe caminhos, interfaces, migrações, testes e erros a partir do repositório real.

Siga as dependências de 013–025. Uma spec ativa por vez; paralelismo apenas em tarefas independentes, com responsável pelos arquivos compartilhados. Não reimplemente o que já atende: comprove e registre o reuso.

Consulte documentação oficial atual para contratos externos. `agent/config.intent.json` é intenção de configuração, não um payload homologado. Valide a combinação Luna/max, ferramentas e saída no endpoint e na conta reais quando houver acesso e autorização.

`scripts/validate_plan.py` verifica o snapshot de planejamento e pressupõe estados iniciais. Não o trate como suíte de runtime nem reverta progresso para fazê-lo passar. Ao incorporar o pacote, preserve a evidência inicial e adapte ou separe a validação contínua para aceitar estados legítimos de execução.

## 5. Limites obrigatórios

Mantenha as cinco ferramentas: `consultar_taliya`, `buscar_material`, `atualizar_contato`, `preparar_proximo_passo` e `solicitar_atendimento_humano`. Elas solicitam operações pequenas; o backend valida identidade, autorização, dados e resultado.

Não autorize contas por e-mail/telefone declarado. Não confirme pagamento pela URL de retorno, fala do usuário ou do modelo. Não duplique gravações entre ferramentas novas, pós-processamento antigo e webhooks.

Implemente processamento recuperável e idempotente. A pausa humana precisa impedir operações e respostas concorrentes/tardias. Não dependa do navegador aberto para concluir uma operação.

Eventos analíticos vêm dos produtores corretos, independentemente da IA. Métricas financeiras vêm do billing; PostHog não controla acesso. A falha de analytics ou do agente não pode impedir a contratação direta.

Não crie prova social, mídia, URL, endpoint, resultado de teste ou disponibilidade comercial fictícios. Fixtures servem somente a testes identificados. Catálogo vazio não autoriza material inventado.

Não afrouxe testes, segurança ou critérios de aceite para declarar uma etapa concluída. Não troque o fallback pelo agente antigo de Pilates.

## 6. Autonomia e autorizações

Pode inspecionar, editar código e documentação locais e executar testes locais isolados. Avance dentro do escopo sem pedir aprovação para cada arquivo ou tarefa. Mudança material de produto, arquitetura, segurança ou gasto exige decisão explícita.

Não publique, migre produção, altere DNS, envie mensagens a pessoas reais, realize operações financeiras ou ative cobrança sem autorização específica. Testes remotos que consomem recursos exigem ambiente e orçamento autorizados. Use credenciais pelo mecanismo seguro do ambiente; nunca peça chaves em texto aberto.

Diante de dependência externa, registre exatamente o bloqueio e avance no trabalho independente. Não marque integração real como concluída com mocks, e não pule dependências fingindo fechar a spec.

## 7. Evidências e continuidade

Ao concluir cada entrega, informe objetivo, arquivos alterados, requisitos atendidos, testes executados com resultados, testes não executados, bloqueios, decisões e próxima tarefa exata.

Mantenha spec/plan/tasks/verification, status e matriz de cobertura coerentes. Registre um único arquivo de continuidade no repositório com commit/snapshot, spec ativa, IDs de tarefas, comandos, resultados e próximo passo; reutilize o existente quando adequado.

Não prometa execução em segundo plano. Se a sessão terminar, deixe um checkpoint que permita continuar sem nova auditoria geral.

“100% pronto” exige código/configuração, integrações reais, testes, operação e gates G0–G6 comprovados. Um plano completo ou testes estruturais não equivalem a produto pronto.

Comece agora pela inspeção do repositório e pela execução da spec de fundação. Se faltar o código, identifique essa ausência concretamente e solicite a fonte necessária; não crie um projeto substituto.
