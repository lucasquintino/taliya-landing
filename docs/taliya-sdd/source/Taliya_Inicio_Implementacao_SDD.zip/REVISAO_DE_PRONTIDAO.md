# Revisão de prontidão para iniciar implementação

**Base:** pacote `Taliya_Plano_Integral_SDD_v3.zip` desta conversa.
**Resultado:** adequado para iniciar a spec de fundação e, em seguida, os recortes dependentes. Não classificado como código pronto, integração homologada ou implantação.

## O que foi verificado nesta revisão

- Abertura e integridade CRC do ZIP.
- Presença dos 95 arquivos do plano.
- Conferência dos hashes e tamanhos de todos os 94 arquivos relacionados no manifesto original (o manifesto não inclui seu próprio hash).
- Leitura do prompt de continuidade, documentos de entrada/governança/dependências, spec de fundação, intenção de configuração e contratos relevantes.
- Nova execução das 87 verificações estruturais do script do plano em uma cópia isolada.
- Validação de oito esquemas com JSON Schema Draft 2020-12.
- Preservação dos bytes do ZIP de origem e dos arquivos do plano incluídos neste pacote de início.

Nenhum teste de comportamento do app ou do agente, instalação de dependências da aplicação, chamada real de API, migração de banco ou publicação foi realizado. Esta revisão também não é uma nova inspeção visual do PDF.

## Dependências por momento

| Dependência | Quando importa |
|---|---|
| Código e interfaces atuais da landing/Internal/app/billing | Fundação e detalhamento dos recortes |
| Spec Kit e ferramentas compatíveis com o ambiente | Preparação antes de implementar |
| Credenciais/permissões e orçamento autorizado de homologação | Testes reais OpenAI, PostHog e integrações |
| Oferta e destinos publicados | Respostas e navegação comerciais |
| Arquivos de mídia, classificação, direitos e aprovação | Publicação e teste dos respectivos materiais |
| Operadores, canais, cadências, retenção e autorizações | Validação operacional e liberação |
| Testes, correções e evidências G0–G6 | Encerramento e produção |

App/assinatura prontos seguem como premissa do usuário, não como algo revalidado contra uma produção acessível nesta revisão. A fundação deve descobrir as interfaces, não reconstruir os produtos.

## Cuidados reforçados no prompt da raiz

1. O pacote é uma base de specs; os planos técnicos devem ser vinculados aos caminhos, payloads e estados reais antes do código de cada recorte.
2. `agent/config.intent.json` não é um pedido pronto para enviar à API. `contracts/` é proposta a adaptar e homologar.
3. `scripts/validate_plan.py` valida o snapshot inicial e contém verificações que exigem estados `not_started`/`not_run`. Não deve virar um gate de CI que impede progresso. Preservar sua evidência inicial; separar/adaptar o validador contínuo ao incorporar os artefatos. Nunca desfazer progresso ou fingir testes para o satisfazer.
4. Iniciar a implementação não autoriza automaticamente operações em produção ou consumo remoto sem orçamento.
5. Falta de uma dependência bloqueia somente o trabalho dependente. Não impede inspeção, especificação técnica ou testes locais independentes.
6. Manter um checkpoint de continuidade e avançar sem outra auditoria geral ou perguntas repetidas sobre decisões já fechadas.

## Limite da conclusão

A estrutura do plano permite começar. Compatibilidade real na conta, qualidade do agente, integração financeira, entrega humana, métricas e recuperação ainda exigem implementação e testes. A linguagem de prontidão distingue esses estados explicitamente.
